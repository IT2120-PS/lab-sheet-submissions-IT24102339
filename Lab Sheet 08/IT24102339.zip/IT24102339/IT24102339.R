setwd("C:\\Users\\kavin\\OneDrive\\Desktop\\IT24102339")
getwd()

data <- read.table('Exercise - Laptopsweights.txt', header = TRUE, sep = ",")
head(data)

weights <- data$Weight.kg

population_mean <- mean(weights)
population_sd <- sd(weights)

cat("Population mean: ", population_mean, "\n" )
cat("Population Standard Deviation: ", population_sd, "\n")

set.seed(123)

num_samples <- 25
sample_size <- 6

sample_means <- numeric(num_samples)
sample_sds <- numeric(num_samples)

for (i in 1:num_samples) {
  sample_data <- sample(weights, size = sample_size, replace = TRUE)
  sample_means[i] <- mean(sample_data)
  sample_sds[i] <- sd(sample_data)
}

cat("sample means: ",sample_means, "\n")
cat("sample SD: ", sample_sds, "\n")

mean_sample_means <- mean(sample_means)
sd_sample_means <- sd(sample_means)

cat("mean of sample means: ", mean_sample_means, "\n")
cat("standard deviation of sample means: ", sd_sample_means, "\n")

standard_error <- population_sd / sqrt(sample_size)
cat("standard error (population SD / sqrt(sample size)): ",standard_error, "\n")