setwd("C:\\Users\\User\\OneDrive\\Desktop\\IT24102339")
getwd()