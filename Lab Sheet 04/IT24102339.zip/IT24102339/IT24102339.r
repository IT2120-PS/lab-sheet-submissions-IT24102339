setwd("C:\\Users\\it24102339\\Desktop\\IT24102339")
getwd()

branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

head(branch_data)

# 1. Identifying the variable type 
str(branch_data)

# 2. Boxplot 
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", horizontal = TRUE)


# 3. Five-number summary and IQR for
summary(branch_data$advertising)
IQR(branch_data$advertising)

# 4.
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers
outliers_in_years <- find_outliers(branch_data$years)
print(outliers_in_years)