setwd("C:\\Users\\User\\OneDrive\\Desktop\\IT24102339")

# Exercise
# 1) 
punif(25,min = 0, max = 40,lower.tail = TRUE) - punif(10,min = 0, max  = 40, lower.tail = TRUE )


# 2) Exponential Distribution
pexp(2,rate = 0.33,lower.tail = TRUE)


# 3)
# i)
# mean = 100 , sd = 15
1 - pnorm(130 , mean = 100, sd = 15, lower.tail = TRUE)
pnorm(130 , mean = 100, sd = 15, lower.tail = FALSE)


# ii)
qnorm(0.95, mean=100, sd=15, lower.tail=TRUE)